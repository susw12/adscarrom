To view the files, enter the .zip file. Then right click the screen (but not a file) and click remove password.
Enter the password provided to you upon login. If you forget it, you can always log back in to get it. Now you
can extract the files from the .zip file and play ADS Carrom!